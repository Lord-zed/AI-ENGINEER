# Task1 question1
name=input("Enter your name: ")
print(name.upper())
# Task1 question2
word="python"
print(word[::5])

# Task1 question3
user_name=input("Enter your name: ")
print("hello",user_name)

#Task1 question4
word1 ="python"
print(word1.index("n"))

#TASK1 QUESTION5
word2= "Hello World"
print( word2.replace("World", "python"))

# Task2 question6
word = "Rat race"
print("python" in word)

#Task2 question7
# 7 Write a program to reverse a string without using slicing (::-1)
word = "Python"
print("".join(reversed(word)))

#Task2 question8
name = "  Indiana  "
print(name.strip())

#Task2 question9
sen = input("Input sentence: ")
print(sen.count("a") + sen.count("e") + sen.count("i") + sen.count("o") + sen.count("u"))

#Task2 question10
string = "1234"
conv = int(string) * 2
print (conv)

#Task3 question11
text = "apple,banana,orange"
print("List of fruits:", text.split(","))

#Task3 question12
sentence = input(" type a sentence: ")
words = sentence.split(" ")
print("\n".join(words))